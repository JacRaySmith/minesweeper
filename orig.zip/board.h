#ifndef LOAD_h
#define LOAD_H

#include "stdio.h"
#include "stdlib.h"
#include "minesweep.h"
#include "cell.h"

game* load_board(char*);
void print_board(game*);

#endif